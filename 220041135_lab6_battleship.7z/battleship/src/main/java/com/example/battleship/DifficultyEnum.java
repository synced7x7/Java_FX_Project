package com.example.battleship;

public enum DifficultyEnum {
    EASY, HARD
}

